HOW TO USE THIS PROJECT

Keep this folder structure exactly:

index.html
assets/
  images/
  videos/
  audio/

Replace files by using the same file names:

Images:
assets/images/home-hero.png
assets/images/intro-poster.png
assets/images/food-hero.png
assets/images/fruit.png
assets/images/vegetable.png
assets/images/protein.png
assets/images/grain.png
assets/images/quiz-character.png
assets/images/reward.png

Video:
assets/videos/intro-video.mp4

Audio:
assets/audio/bgm.mp3
assets/audio/click.mp3
assets/audio/correct.mp3
assets/audio/wrong.mp3

GitHub Pages:
Upload index.html and the assets folder to the same repository.
Then enable Settings > Pages > Deploy from branch > main > /root.
