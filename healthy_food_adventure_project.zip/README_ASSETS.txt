QIM516 Project 1 asset package

Use this folder structure in your GitHub repository:

index.html
assets/
  images/
    intro-poster.png
    home-hero.png
    food-hero.png
    fruit.png
    vegetable.png
    protein.png
    grain.png
    quiz-character.png
    reward.png
  videos/
    intro-video.mp4
  audio/
    bgm.mp3
    click.mp3
    correct.mp3
    wrong.mp3

The HTML has already been prepared to load:
assets/videos/intro-video.mp4
assets/images/intro-poster.png
assets/audio/bgm.mp3
assets/audio/click.mp3
assets/audio/correct.mp3
assets/audio/wrong.mp3
